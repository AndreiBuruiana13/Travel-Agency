<?php include 'includes/header.php'; ?>

    <section id="hero">
        <h2>Descoperă Lumea alături de Noi!</h2>
        <p>Planifică-ți vacanța de vis cu cele mai bune oferte și destinații exotice.</p>
        <img src="images/hero-image.jpg" alt="Vedere spectaculoasă la plajă cu palmieri" style="width:100%; max-width:800px;">
    </section>

    <section id="oferte-speciale">
        <h2>Oferte Speciale</h2>
        <p>Nu rata pachetele noastre promoționale:</p>
        <div class="oferte-container">
            <div class="oferta-card">
                <div class="oferta-header">
                    <h3>Excursie în Thailanda - 7 zile / 6 nopți</h3>
                    <span class="toggle-icon">+</span>
                </div>
                <div class="oferta-content">
                    <p>Descoperă plajele paradisiace, templele antice și cultura vibrantă din Thailanda. Acest pachet include cazare 6 nopți la hotel de 4 stele, mic dejun, bilete de avion și excursii la cele mai importante atracții. O aventură exotică te așteaptă!</p>
                    <p><strong>Preț de la:</strong> 1200 €</p>
                    <p><a href="detalii-destinatie.php?id=thailanda" class="btn-detalii">Vezi detalii complete</a></p>
                </div>
            </div>

            <div class="oferta-card">
                <div class="oferta-header">
                    <h3>Circuit cultural în Italia - 10 zile / 9 nopți</h3>
                    <span class="toggle-icon">+</span>
                </div>
                <div class="oferta-content">
                    <p>O călătorie fascinantă prin istoria și arta Italiei. Vizitează Roma, Florența, Veneția și multe altele. Include 9 nopți cazare, transport cu autocar, ghid turistic și intrări la muzee principale. Savurează bucătăria italiană autentică!</p>
                    <p><strong>Preț de la:</strong> 950 €</p>
                    <p><a href="detalii-destinatie.php?id=italia" class="btn-detalii">Vezi detalii complete</a></p>
                </div>
            </div>

            <div class="oferta-card">
                <div class="oferta-header">
                    <h3>Aventură în Munții Carpați - 3 zile / 2 nopți</h3>
                    <span class="toggle-icon">+</span>
                </div>
                <div class="oferta-content">
                    <p>Evadează în inima naturii românești. Trei zile de drumeții montane, aer curat și peisaje spectaculoase. Include 2 nopți cazare la pensiune montană, mic dejun și ghid montan. Perfect pentru iubitorii de natură și adrenalină!</p>
                    <p><strong>Preț de la:</strong> 250 €</p>
                    <p><a href="detalii-destinatie.php?id=carpati" class="btn-detalii">Vezi detalii complete</a></p>
                </div>
            </div>
        </div>
    </section>
    <?php include 'includes/footer.php'; ?>