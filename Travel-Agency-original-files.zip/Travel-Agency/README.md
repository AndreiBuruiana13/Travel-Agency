# Travel Agency Website

Surviving files from a university PHP, HTML, CSS and JavaScript project. Only the original homepage survives; referenced includes, styles and other pages are missing. This is an incomplete source archive, not a working application.
